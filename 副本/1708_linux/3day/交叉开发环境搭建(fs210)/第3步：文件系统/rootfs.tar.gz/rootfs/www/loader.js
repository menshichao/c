
/***´´½¨һ¸�HTTPRequest¶Տ񋈍
**՚²»טт¼Ԕْ³ĦµŇꀶЂ¸�³
**՚ҳĦӑ¼Ԕغ󵓷�숳˽¾ۍ
**՚ҳĦӑ¼Ԕغ󵓷�Ԋ֊�*՚º􌩏򸿎򇷷¢̍˽¾ۍ
***/
function createXHR() 
{
	var xhr;
    	try 
    	{
        		xhr = new ActiveXObject("Msxml2.XMLHTTP");
    	} 
    	catch (e) 
    	{
        		try 
        		{
            		xhr = new ActiveXObject("Microsoft.XMLHTTP");
        		}
        		catch(E) 
        		{
            		xhr = false;
        		}
    	}
    	if (!xhr && typeof XMLHttpRequest != 'undefined') 
    	{
       		xhr = new XMLHttpRequest();
    	}
    return xhr;
}

function do_nothing()
{
	;
}

/*
 * 异步回调函数处理
 */
function callbackFunction()
{
/*
   if (xhr.readyState == 4) 
   {
       if (xhr.status == 200) 
       {
            var returnValue = xhr.responseText;
            if(returnValue != null && returnValue.length > 0)
            {
                   document.getElementById("temperature").innerHTML = returnValue;
            }
            else
            {
                  alert("结果为空！");
            }
       } 
       else 
       {
            alert("页面出现异常！");
	   }
   }
*/
}

/*
 * 异步回调函数处理(系统信息）
 */
function callbackFunction_refresh_msg()
{
   if (xhr.readyState == 4) 
   {   	
       if (xhr.status == 200) 
       {
            var returnValue = xhr.responseText;
            if(returnValue != null && returnValue.length > 0)
            {
                   document.getElementById("msginfo").innerHTML = returnValue;
            }
            else
            {
                  alert("结果为空！");
            }
       } 
       else 
       { 
            //alert("页面出现异常_loader.js!, xhr.status = " + xhr.status);
	   }
   }
}

/*
 * 异步回调函数处理(温度）
 */
function callbackFunction_refresh()
{
   if (xhr.readyState == 4) 
   {
       if (xhr.status == 200) 
       {
            var returnValue = xhr.responseText;
            if(returnValue != null && returnValue.length > 0)
            {
                   document.getElementById("temperature").innerHTML = returnValue;
            }
            else
            {
                  alert("结果为空！");
            }
       } 
       else 
       {
            alert("页面出现异常！");
	   }
   }
}

/*  
 *   异步访问提交处理  
 */
function sender() 
{
	xhr = createXHR();
	if(xhr)
	{
	        xhr.onreadystatechange=callbackFunction;
	        //test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
     		xhr.open("GET", "./cgi-bin/cgi_led?led=" + document.getElementById("led").value +"&date=" + Date());
		xhr.send(null);
	}
	else
	{
	//XMLHttpRequest对象创建失败
	alert("浏览器不支持，请更换浏览器！");
	}
}


/*
 * 温度
*/
function sender_refresh() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=callbackFunction_refresh;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?1="+ Date());
		xhr.send(null);
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}

/*
 * 刷新系统信息
*/
function msg_refresh() 
{
	//alert("call msg_refresh1()");
	xhr = createXHR();
	if(xhr)
	{
		//alert("call msg_refresh2()");
		xhr.onreadystatechange = callbackFunction_refresh_msg;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?13 = " + Date());
		xhr.send(null);
	 }
	else	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}

/*
 * 报警设置
 */
function sender_alarm_set() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/alarm_set.cgi?alarm_freq="+ document.getElementById("alarm_freq").value + "&alarm_time=" + 			  document.getElementById("alarm_time").value);
		xhr.send(null);
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}


/*
 * 打开监控 
 */
function sender_view_on() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?3="+Date());
		xhr.send(null);
		alert("监控系统已启动!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}


/*
 * 关闭监控
 */
function sender_view_off() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?4="+Date());
		xhr.send(null);
		alert("监控系统已关闭!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}

/*
 * 手机设置
 */
function sender_sms_set()
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		//alert("./cgi-bin/control.cgi?5="+document.getElementById("sms_number").value +"&7="+document.getElementById("sms_context").value);
		xhr.open("GET", "./cgi-bin/control.cgi?5="+document.getElementById("sms_number").value +"&7="+document.getElementById("sms_context").value);
		xhr.send(null);
		alert("设置完成!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}

/*
 * 报警温度设置
 */
function sender_alarm_temp_set()
{
	xhr = createXHR();
	if(xhr)
	{
		//alert("./cgi-bin/control.cgi?2="+document.getElementById("alarm_temp").value + "&date=" + Date());
		xhr.onreadystatechange = do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		// 2 = 23&date = Mon Apr 05 18:27:55 2010
		xhr.open("GET", "./cgi-bin/control.cgi?2 = "+ document.getElementById("alarm_temp").value + "&date = " + Date());
		xhr.send(null);
		alert("报警温度设置完成!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}
/*
 * 
 * 	抓图
 */
function sender_capturet()
{
	xhr = createXHR();
	if(xhr)
	{
		//alert("./cgi-bin/control.cgi?2="+document.getElementById("alarm_temp").value + "&date=" + Date());
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?14="+Date());
		xhr.send(null);
		alert("抓图完成!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}
/*
 * 允许发送短信
 */
function sender_sms_on()
{
	xhr = createXHR();
	if(xhr)
	{
		//alert("./cgi-bin/control.cgi?2="+document.getElementById("alarm_temp").value + "&date=" + Date());
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?6="+Date());
		xhr.send(null);
		alert("设置完成!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}
/*
 * 关闭发送短信
 */
function sender_sms_off()
{
	xhr = createXHR();
	if(xhr)
	{
		//alert("./cgi-bin/control.cgi?2="+document.getElementById("alarm_temp").value + "&date=" + Date());
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?12="+Date());
		xhr.send(null);
		alert("设置完成!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}

/*
 * 点亮LED
 */
function open_led()
{
			xhr = createXHR();
			if(xhr)
			{
				xhr.onreadystatechange=do_nothing;
				//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
				xhr.open("GET", "./cgi-bin/control.cgi?15="+ Date());  
				//在control.c中定义了宏：#define OPEN_LED 15 ，该语句执行后将会调用control.c中的open_led()函数，打开/dev/led_drv设备
				xhr.send(null);
				alert("请注意：若监控打开，将无法操作！");
			 }
			else
			{
				//XMLHttpRequest对象创建失败
				alert("浏览器不支持，请更换浏览器！");
			}
}


/*
 * 关闭LED
 */
function close_led() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?16="+ Date());
		//在control.c中定义了宏：#define CLOSE_LED			16，该语句执行后将会调用control.c中的close_led()函数，关闭/dev/led_drv设备
		xhr.send(null);
		alert("请注意：若监控打开，将无法操作！");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}

/*
 * 点亮LED 
 */
function open_led_test()
{
			xhr = createXHR();
			if(xhr)
			{
				xhr.onreadystatechange=do_nothing;
				//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
				xhr.open("GET", "./cgi-bin/control.cgi?21="+ Date());  
				//在control.c中定义了宏：#define OPEN_LED 15 ，该语句执行后将会调用control.c中的open_led()函数，打开/dev/led_drv设备
				xhr.send(null);
			 }
			else
			{
				//XMLHttpRequest对象创建失败
				alert("浏览器不支持，请更换浏览器！");
			}
}


/*
 * 关闭LED_ 
 */
function close_led_test() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?22="+ Date());
		//在control.c中定义了宏：#define CLOSE_LED			16，该语句执行后将会调用control.c中的close_led()函数，关闭/dev/led_drv设备
		xhr.send(null);
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}
/*
 * 打开电风扇
 */
function open_fan() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?17="+Date());
		xhr.send(null);
		alert("请注意：若监控打开，将无法操作！");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}


/*
 * 关闭电风扇
 */
function close_fan() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?18="+Date());
		xhr.send(null);
		alert("请注意：若监控打开，将无法操作！");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
} 

/*
 * 打开蜂鸣器
 */
function open_buzzer() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?19="+Date());
		xhr.send(null);
		alert("请注意：若监控打开，将无法操作！");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}


/*
 * 关闭蜂鸣器灯
 */
function close_buzzer() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?20="+Date());
		xhr.send(null);
		alert("请注意：若监控打开，将无法操作！");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
} 

/*
 * 打开电风扇监控
 */
function set_open_fan() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?25="+Date());
		xhr.send(null);
		//alert("电风扇已打开!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}


/*
 * 关闭电风扇监控
 */
function set_close_fan() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?26="+Date());
		xhr.send(null);
		//alert("电风扇已关闭!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
} 

/*
 * 打开蜂鸣器监控
 */
function set_open_buzzer() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?27="+Date());
		xhr.send(null);
		//alert("蜂鸣器已打开!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}


/*
 * 关闭蜂鸣器灯监控
 */
function set_close_buzzer() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?28="+Date());
		xhr.send(null);
	//	alert("蜂鸣器已关闭!");
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
} 

/*
 * 点亮LED监控 
 */
function set_open_led()
{
			xhr = createXHR();
			if(xhr)
			{
				xhr.onreadystatechange=do_nothing;
				//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
				xhr.open("GET", "./cgi-bin/control.cgi?23="+ Date());  
				//在control.c中定义了宏：#define OPEN_LED 15 ，该语句执行后将会调用control.c中的open_led()函数，打开/dev/led_drv设备
				xhr.send(null);
			 }
			else
			{
				//XMLHttpRequest对象创建失败
				alert("浏览器不支持，请更换浏览器！");
			}
}


/*
 * 关闭LED监控
 */
function set_close_led() 
{
	xhr = createXHR();
	if(xhr)
	{
		xhr.onreadystatechange=do_nothing;
		//test.cgi后面跟个cur_time参数是为了防止Ajax页面缓存
		xhr.open("GET", "./cgi-bin/control.cgi?24="+ Date());
		//在control.c中定义了宏：#define CLOSE_LED			16，该语句执行后将会调用control.c中的close_led()函数，关闭/dev/led_drv设备
		xhr.send(null);
	 }
	else
	{
		//XMLHttpRequest对象创建失败
		alert("浏览器不支持，请更换浏览器！");
	}
}